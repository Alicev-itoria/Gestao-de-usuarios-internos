package ifal.edu.br.serv;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;

import ifal.edu.br.Conexao;

/**
 * Servlet implementation class acoes
 */
@WebServlet("/acoes")
public class acoes extends HttpServlet {
	private static final long serialVersionUID = 1L;
       

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		String dataAcao = request.getParameter("dataAcao");
        String tipoAcao = request.getParameter("tipoAcao");
        String referenciaExternaID = request.getParameter("referenciaExternaID");

        try (Connection conn = Conexao.getConnection()) {
            String sql = "INSERT INTO ACAOUSUARIO (DATAACAO, TIPOACAO, REFERENCIAEXTERNAID) VALUES (?, ?, ?)";
            PreparedStatement stmt = conn.prepareStatement(sql);
            stmt.setString(1, dataAcao);
            stmt.setString(2, tipoAcao);
            stmt.setString(3, referenciaExternaID);
            stmt.executeUpdate();

            System.out.println("Ação cadastrada: " + tipoAcao + " em " + dataAcao);

        } catch (Exception e) {
            System.err.println("Erro ao cadastrar ação: " + e.getMessage());
            e.printStackTrace();
        }

        response.sendRedirect("PaginaInicial.html");
		
	}

}
