package ifal.edu.br.serv;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;

import ifal.edu.br.Conexao;

/**
 * Servlet implementation class CadastroU
 */
@WebServlet("/CadastroU")
public class CadastroU extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public CadastroU() {
        super();
        // TODO Auto-generated constructor stub
    }


	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		
		
		 String nome = request.getParameter("nome");
	        String email = request.getParameter("email");
	        String matricula = request.getParameter("matricula");
	        String cargo = request.getParameter("cargo");
	        String status = request.getParameter("status");

	        try (Connection conn = Conexao.getConnection()) {

	            String sql = "INSERT INTO Usuario (nomeCompleto, email, matricula, cargo, status) " +
	                         "VALUES (?, ?, ?, ?, ?)";

	            PreparedStatement ps = conn.prepareStatement(sql);
	            ps.setString(1, nome);
	            ps.setString(2, email);
	            ps.setString(3, matricula);
	            ps.setString(4, cargo);
	            ps.setString(5, status);

	            ps.executeUpdate();
	            ps.close();

	        } catch (Exception e) {
	            e.printStackTrace();
	        }

	        // Redireciona para o menu ou para a página de consulta
	        response.sendRedirect("PaginaInicial.html");
	}

}
