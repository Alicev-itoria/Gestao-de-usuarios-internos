package ifal.edu.br;

public class AcaoUsuario {

	private int acaoID;
    private String dataAcao;
    private String tipoAcao; 
    private String referenciaExternaID;
    
	public int getAcaoID() {
		return acaoID;
	}
	public void setAcaoID(int acaoID) {
		this.acaoID = acaoID;
	}
	public String getDataAcao() {
		return dataAcao;
	}
	public void setDataAcao(String dataAcao) {
		this.dataAcao = dataAcao;
	}
	public String getTipoAcao() {
		return tipoAcao;
	}
	public void setTipoAcao(String tipoAcao) {
		this.tipoAcao = tipoAcao;
	}
	public String getReferenciaExternaID() {
		return referenciaExternaID;
	}
	public void setReferenciaExternaID(String referenciaExternaID) {
		this.referenciaExternaID = referenciaExternaID;
	}

}
