package ifal.edu.br;

import java.sql.Connection;

import java.sql.DriverManager;

public class Conexao {

	
	public static Connection getConnection() throws Exception{
		
		 Class.forName("org.h2.Driver");
		String url="jdbc:h2:file:C:/Users/adrie/h2-2025-09-22/h2/bin/meubd";
		String user="sa";
		String senha="";
		
		
		return DriverManager.getConnection(url,user,senha);
		
	}
}
