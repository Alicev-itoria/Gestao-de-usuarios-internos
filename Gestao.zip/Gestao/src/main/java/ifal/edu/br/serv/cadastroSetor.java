package ifal.edu.br.serv;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;

import ifal.edu.br.Conexao;

/**
 * Servlet implementation class cadastroSetor
 */
@WebServlet("/cadastroSetor")
public class cadastroSetor extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
   
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
	
		 String nomeSetor = request.getParameter("nomeSetor");

	        try (Connection conn = Conexao.getConnection()) {
	            String sql = "INSERT INTO SETOR (NOMESETOR) VALUES (?)";
	            PreparedStatement stmt = conn.prepareStatement(sql);
	            stmt.setString(1, nomeSetor);
	            stmt.executeUpdate();

	            System.out.println("Setor cadastrado: " + nomeSetor);

	        } catch (Exception e) {
	            System.err.println("Erro ao cadastrar setor: " + e.getMessage());
	            e.printStackTrace();
	        }

	
	        response.sendRedirect("PaginaInicial.html");
		
		
		
		
		
	}

}
