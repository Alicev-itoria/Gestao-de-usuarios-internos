package ifal.edu.br;

public class Setor {

	
	private int setorID;
    private String nomeSetor;
    
	public int getSetorID() {
		return setorID;
	}
	public void setSetorID(int setorID) {
		this.setorID = setorID;
	}
	public String getNomeSetor() {
		return nomeSetor;
	}
	public void setNomeSetor(String nomeSetor) {
		this.nomeSetor = nomeSetor;
	}
}
