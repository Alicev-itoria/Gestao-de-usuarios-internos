package ifal.edu.br.serv;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import ifal.edu.br.Conexao;
import ifal.edu.br.Usuario;

/**
 * Servlet implementation class editarU
 */
@WebServlet("/editarU")
public class editarU extends HttpServlet {
	private static final long serialVersionUID = 1L;
  
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		String idParam = request.getParameter("id");
        if (idParam != null) {
            int id = Integer.parseInt(idParam);
            Usuario usuario = null;
            try (Connection conn = Conexao.getConnection()) {
                PreparedStatement ps = conn.prepareStatement("SELECT * FROM Usuario WHERE usuarioid = ?");
                ps.setInt(1, id);
                ResultSet rs = ps.executeQuery();
                if (rs.next()) {
                    usuario = new Usuario();
                    usuario.setUsuarioID(rs.getInt("usuarioid"));
                    usuario.setNomeCompleto(rs.getString("nomeCompleto"));
                    usuario.setEmail(rs.getString("email"));
                    usuario.setMatricula(rs.getString("matricula"));
                    usuario.setCargo(rs.getString("cargo"));
                    usuario.setStatus(rs.getString("status"));
                }
                rs.close();
                ps.close();
            } catch (Exception e) {
                e.printStackTrace();
            }
            request.setAttribute("usuario", usuario);
            request.getRequestDispatcher("editar.jsp").forward(request, response);
        } else {
            response.sendRedirect("consulta");
        }
	}

	

}
