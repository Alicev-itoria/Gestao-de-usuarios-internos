package ifal.edu.br.serv;

import jakarta.servlet.RequestDispatcher;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import java.util.ArrayList;
import java.util.List;

import ifal.edu.br.Conexao;
import ifal.edu.br.Usuario;


@WebServlet("/consulta")
public class consulta extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
	
		
		  List<Usuario> usuarios = new ArrayList<>();
   
		  String sql ="SELECT * FROM Usuario";
		
	     
		  
		  try (Connection conn = Conexao.getConnection()) {
	            PreparedStatement stmt = conn.prepareStatement(sql);
	            ResultSet rs = stmt.executeQuery();

	            while(rs.next()) {
	            	Usuario u = new Usuario();
	            	u.setUsuarioID(rs.getInt("USUARIOID"));
	            	u.setNomeCompleto(rs.getString("NOMECOMPLETO"));
	            	u.setEmail(rs.getString("EMAIL"));
	            	u.setMatricula(rs.getString("MATRICULA"));
	            	u.setCargo(rs.getString("CARGO"));
	            	u.setStatus(rs.getString("STATUS"));
	                usuarios.add(u);
	                
	                System.out.println("Usuario encontrado: " + u.getNomeCompleto());
	               

	            }

  

	        } catch(Exception e) {
	        	System.err.println("Ocorreu um erro ao listar os eventos: " + e.getMessage());
	        	System.out.println(e.getMessage());
	            e.printStackTrace();
	        }
		  
		  request.setAttribute("usuarios", usuarios);
		  RequestDispatcher dispacher=request.getRequestDispatcher("ConsultarUsuario.jsp");
		  dispacher.forward(request, response);
	
	    }
		
		

		
		
		
		
	}

	


