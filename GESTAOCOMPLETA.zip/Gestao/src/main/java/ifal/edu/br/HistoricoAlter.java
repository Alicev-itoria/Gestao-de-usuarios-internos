package ifal.edu.br;

public class HistoricoAlter {

	private int historicoID;
    private String dataAlteracao;
    private String campoAlterado;
    private String valorAntigo;
    private String valorNovo;
    
	public int getHistoricoID() {
		return historicoID;
	}
	public void setHistoricoID(int historicoID) {
		this.historicoID = historicoID;
	}
	public String getDataAlteracao() {
		return dataAlteracao;
	}
	public void setDataAlteracao(String dataAlteracao) {
		this.dataAlteracao = dataAlteracao;
	}
	public String getCampoAlterado() {
		return campoAlterado;
	}
	public void setCampoAlterado(String campoAlterado) {
		this.campoAlterado = campoAlterado;
	}
	public String getValorAntigo() {
		return valorAntigo;
	}
	public void setValorAntigo(String valorAntigo) {
		this.valorAntigo = valorAntigo;
	}
	public String getValorNovo() {
		return valorNovo;
	}
	public void setValorNovo(String valorNovo) {
		this.valorNovo = valorNovo;
	}


}
