package ifal.edu.br.api;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

import com.google.gson.Gson;

import ifal.edu.br.Conexao;
import ifal.edu.br.Usuario;

@WebServlet("/api/usuarios/*")
public class     Restserveletapi extends HttpServlet {
    private static final long serialVersionUID = 1L;
    private Gson gson = new Gson();

    // GET /api/usuarios ou /api/usuarios/{id}
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        response.setContentType("application/json");
        String pathInfo = request.getPathInfo(); // /{id} ou null
        PrintWriter out = response.getWriter();

        try (Connection conn = Conexao.getConnection()) {
            if (pathInfo == null || pathInfo.equals("/")) {
                // Lista todos
                List<Usuario> usuarios = new ArrayList<>();
                PreparedStatement ps = conn.prepareStatement("SELECT * FROM Usuario");
                ResultSet rs = ps.executeQuery();
                while(rs.next()) {
                    Usuario u = new Usuario();
                    u.setUsuarioID(rs.getInt("usuarioid"));
                    u.setNomeCompleto(rs.getString("nomeCompleto"));
                    u.setEmail(rs.getString("email"));
                    u.setMatricula(rs.getString("matricula"));
                    u.setCargo(rs.getString("cargo"));
                    u.setStatus(rs.getString("status"));
                    usuarios.add(u);
                }
                out.print(gson.toJson(usuarios));
            } else {
                // Busca por ID
                int id = Integer.parseInt(pathInfo.substring(1));
                PreparedStatement ps = conn.prepareStatement("SELECT * FROM Usuario WHERE usuarioid = ?");
                ps.setInt(1, id);
                ResultSet rs = ps.executeQuery();
                if(rs.next()) {
                    Usuario u = new Usuario();
                    u.setUsuarioID(rs.getInt("usuarioid"));
                    u.setNomeCompleto(rs.getString("nomeCompleto"));
                    u.setEmail(rs.getString("email"));
                    u.setMatricula(rs.getString("matricula"));
                    u.setCargo(rs.getString("cargo"));
                    u.setStatus(rs.getString("status"));
                    out.print(gson.toJson(u));
                } else {
                    response.setStatus(HttpServletResponse.SC_NOT_FOUND);
                    out.print("{\"erro\":\"Usuário não encontrado\"}");
                }
            }
        } catch(Exception e) {
            response.setStatus(HttpServletResponse.SC_INTERNAL_SERVER_ERROR);
            out.print("{\"erro\":\"" + e.getMessage() + "\"}");
            e.printStackTrace();
        }
    }

    // POST /api/usuarios
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        response.setContentType("application/json");
        Usuario u = gson.fromJson(request.getReader(), Usuario.class);

        try (Connection conn = Conexao.getConnection()) {
            PreparedStatement ps = conn.prepareStatement(
                "INSERT INTO Usuario(nomeCompleto, email, matricula, cargo, status) VALUES (?, ?, ?, ?, ?)",
                Statement.RETURN_GENERATED_KEYS
            );
            ps.setString(1, u.getNomeCompleto());
            ps.setString(2, u.getEmail());
            ps.setString(3, u.getMatricula());
            ps.setString(4, u.getCargo());
            ps.setString(5, u.getStatus());
            ps.executeUpdate();

            ResultSet rs = ps.getGeneratedKeys();
            if(rs.next()) {
                u.setUsuarioID(rs.getInt(1));
            }

            response.setStatus(HttpServletResponse.SC_CREATED);
            PrintWriter out = response.getWriter();
            out.print(gson.toJson(u));
        } catch(Exception e) {
            response.setStatus(HttpServletResponse.SC_INTERNAL_SERVER_ERROR);
            response.getWriter().print("{\"erro\":\"" + e.getMessage() + "\"}");
            e.printStackTrace();
        }
    }

    // PUT /api/usuarios/{id}
    @Override
    protected void doPut(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        response.setContentType("application/json");
        String pathInfo = request.getPathInfo();
        PrintWriter out = response.getWriter();

        if(pathInfo == null || pathInfo.equals("/")) {
            response.setStatus(HttpServletResponse.SC_BAD_REQUEST);
            out.print("{\"erro\":\"ID do usuário é necessário\"}");
            return;
        }

        int id = Integer.parseInt(pathInfo.substring(1));
        Usuario u = gson.fromJson(request.getReader(), Usuario.class);

        try (Connection conn = Conexao.getConnection()) {
            PreparedStatement ps = conn.prepareStatement(
                "UPDATE Usuario SET nomeCompleto = ?, email = ?, matricula = ?, cargo = ?, status = ? WHERE usuarioid = ?"
            );
            ps.setString(1, u.getNomeCompleto());
            ps.setString(2, u.getEmail());
            ps.setString(3, u.getMatricula());
            ps.setString(4, u.getCargo());
            ps.setString(5, u.getStatus());
            ps.setInt(6, id);

            int updated = ps.executeUpdate();
            if(updated > 0) {
                u.setUsuarioID(id);
                out.print(gson.toJson(u));
            } else {
                response.setStatus(HttpServletResponse.SC_NOT_FOUND);
                out.print("{\"erro\":\"Usuário não encontrado\"}");
            }
        } catch(Exception e) {
            response.setStatus(HttpServletResponse.SC_INTERNAL_SERVER_ERROR);
            out.print("{\"erro\":\"" + e.getMessage() + "\"}");
            e.printStackTrace();
        }
    }

    // DELETE /api/usuarios/{id}
    @Override
    protected void doDelete(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        response.setContentType("application/json");
        String pathInfo = request.getPathInfo();
        PrintWriter out = response.getWriter();

        if(pathInfo == null || pathInfo.equals("/")) {
            response.setStatus(HttpServletResponse.SC_BAD_REQUEST);
            out.print("{\"erro\":\"ID do usuário é necessário\"}");
            return;
        }

        int id = Integer.parseInt(pathInfo.substring(1));

        try (Connection conn = Conexao.getConnection()) {
            PreparedStatement ps = conn.prepareStatement("DELETE FROM Usuario WHERE usuarioid = ?");
            ps.setInt(1, id);
            int deleted = ps.executeUpdate();
            if(deleted > 0) {
                out.print("{\"mensagem\":\"Usuário deletado com sucesso\"}");
            } else {
                response.setStatus(HttpServletResponse.SC_NOT_FOUND);
                out.print("{\"erro\":\"Usuário não encontrado\"}");
            }
        } catch(Exception e) {
            response.setStatus(HttpServletResponse.SC_INTERNAL_SERVER_ERROR);
            out.print("{\"erro\":\"" + e.getMessage() + "\"}");
            e.printStackTrace();
        }
    }
}
