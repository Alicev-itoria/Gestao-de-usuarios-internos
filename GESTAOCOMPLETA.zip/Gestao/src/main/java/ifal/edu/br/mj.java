package ifal.edu.br;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

public class mj {
   
	public static void main(String[] args) {
		   String sql = "SELECT * FROM USUARIO"; // tabela em maiúsculas

	        try (Connection conn = Conexao.getConnection();
	             PreparedStatement stmt = conn.prepareStatement(sql);
	             ResultSet rs = stmt.executeQuery()) {

	            System.out.println("Lista de usuários no banco:");

	            boolean encontrou = false;

	            while (rs.next()) {
	                encontrou = true;
	                String nome = rs.getString("NOMECOMPLETO");
	                String email = rs.getString("EMAIL");
	                String matricula = rs.getString("MATRICULA");
	                String cargo = rs.getString("CARGO");
	                String status = rs.getString("STATUS");

	                System.out.println("Nome: " + nome
	                        + " | Email: " + email
	                        + " | Matrícula: " + matricula
	                        + " | Cargo: " + cargo
	                        + " | Status: " + status);
	            }

	            if (!encontrou) {
	                System.out.println("Nenhum usuário encontrado no banco!");
	            }

	        } catch (Exception e) {
	            System.err.println("Erro ao acessar o banco: " + e.getMessage());
	            e.printStackTrace();
	        }
	}
	
}
