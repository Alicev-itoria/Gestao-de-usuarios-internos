

package ifal.edu.br;

public class PerfilAcesso {

	
	private int perfilID;
    private String nomePerfil;
	public int getPerfilID() {
		return perfilID;
	}
	public void setPerfilID(int perfilID) {
		this.perfilID = perfilID;
	}
}
