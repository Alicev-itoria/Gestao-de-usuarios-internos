package ifal.edu.br.serv;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;

import ifal.edu.br.Conexao;

/**
 * Servlet implementation class AtualizarUsuario
 */
@WebServlet("/AtualizarUsuario")
public class AtualizarUsuario extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
     @Override
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		
		 String id = request.getParameter("id");
	        String nome = request.getParameter("nome");
	        String email = request.getParameter("email");
	        String matricula = request.getParameter("matricula");
	        String cargo = request.getParameter("cargo");
	        String status = request.getParameter("status");

	        try (Connection conn = Conexao.getConnection()) {
	            String sql = "UPDATE Usuario SET nomeCompleto = ?, email = ?, matricula = ?, cargo = ?, status = ? WHERE usuarioid = ?";
	            PreparedStatement ps = conn.prepareStatement(sql);
	            ps.setString(1, nome);
	            ps.setString(2, email);
	            ps.setString(3, matricula);
	            ps.setString(4, cargo);
	            ps.setString(5, status);
	            ps.setInt(6, Integer.parseInt(id));

	            ps.executeUpdate();
	            ps.close();
	        } catch (Exception e) {
	            e.printStackTrace();
	        }

	        response.sendRedirect("consulta");
	}

}
