package ifal.edu.br;

public class UsuarioPerfis {

	private int usuarioID;
    private int perfilID;
	public int getUsuarioID() {
		return usuarioID;
	}
	public void setUsuarioID(int usuarioID) {
		this.usuarioID = usuarioID;
	}
	public int getPerfilID() {
		return perfilID;
	}
	public void setPerfilID(int perfilID) {
		this.perfilID = perfilID;
	}
}
